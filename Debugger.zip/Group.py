class Group:
    def __init__(self, size, time, id) -> None:
        self.size = size
        self.time = time
        self.id = id
        self.interest = {}