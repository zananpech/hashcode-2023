class Destination:
    def __init__(self, category, rating, duration, price, name) -> None:
        self.category = category
        self.rating = rating
        self.duration = duration
        self.price = price
        self.name = name